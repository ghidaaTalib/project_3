#!/bin/bash

node -r esm 01-binary-search-array.js
node -r esm 02-sliding-window-max.js
node -r esm 03-search-rotated-array.js
node -r esm 04-arrays-smallest-common.js
node -r esm 05-rotate-array.js
node -r esm 06-low-high-indices.js
node -r esm 07-move-zeroes.js
node -r esm 08-max-pro.js
node -r esm 09-merge-intervals.js
node -r esm 10-2-subset-sum.js
node -r esm 11-quick-sort.js
