- Answers 1 - 4
- All these solutions I achieved without looking at any answers. Question 4 took me a long time tho. But it's satisfying to know that you can search over two sorted arrays as if they were merged in only, log(m+n) time. Pretty fucking cool. Fucking ripper eh mate. :P ;) xxx chakka haahahaha
- Answers 5 and up
- I'm giong to start looking at answers to save time. I proved I can do it and work it out myself (in all three grades: Easy, Medium, Hard) without looking up answers, and now I want to focus on moving faster.

