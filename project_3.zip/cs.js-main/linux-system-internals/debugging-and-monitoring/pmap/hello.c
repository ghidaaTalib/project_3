#include <stdio.h>

int main() {
  printf("Hello, World!\n");
  while(1) {}
  return 0;
}
