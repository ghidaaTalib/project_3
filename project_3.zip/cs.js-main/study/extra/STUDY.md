
Grokking the System Design Interview (https://www.educative.io/collection/5668639101419520/5649050225344512)

Coupon: 0b4a9a73-948b-4da3-a5ce-2ab7f1f19e12

 

Coderust: Hacking the Coding Interview (https://www.educative.io/collection/5642554087309312/5679846214598656)

Coupon: bedb9fce-87c1-4c0a-a000-cf0191e2e10a

 

In this course, focus on parts 1 through 4: Arrays, Linked Lists, Math & Stats and Strings. If you have some extra time, it wouldn’t hurt to get a grasp of 5 and 6 which are trees and stacks/queues.

 

However, in general, you should definitely be comfortable with algorithmic complexity (basics of big O notation), opening and reading files, data structures (hash tables), anything about at-scale edge cases (size larger than memory, etc).
