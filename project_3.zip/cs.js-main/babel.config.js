// babel.config.js
module.exports = {
  plugins: [
    "@babel/plugin-syntax-class-properties"
  ]
};
